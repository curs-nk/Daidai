﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

// 关于程序集的一般信息通过以下 
// 属性集来控制。请更改这些属性值以修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("WpfEXE")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("微软中国")]
[assembly: AssemblyProduct("WpfEXE")]
[assembly: AssemblyCopyright("Copyright © 微软中国 2011")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// 如果将 ComVisible 设置为 False，则此程序集中的类型 
// 对于 COM 组件不可见。如果需要从 COM 访问此程序集中的 
// 类型，请针对该类型将 ComVisible 属性设置为 True。
[assembly: ComVisible(false)]

// 如果此项目向 COM 公开，则以下 GUID 表示类型库的 ID
[assembly: Guid("f3fd4cea-b190-4c75-9ecd-f2d3810685dc")]

//为了开始生成可本地化的应用程序，请 
//在 .csproj 文件中 <PropertyGroup> 内
//设置  <UICulture>CultureYouAreCodingWith</UICulture>。例如，如果您在源
//文件中使用美国英语，请将 <UICulture> 设置为 "en-US"。然后取消注释
//以下 NeutralResourceLanguage 属性。请更新以下行中的 "en-US" 以
//与项目文件中的 UICulture 设置匹配。

//[assembly: NeutralResourcesLanguage("en-US" , UltimateResourceFallbackLocation.MainAssembly)]

[assembly:ThemeInfo(
    ResourceDictionaryLocation.None, //主题特定资源字典的位置
                             //(在页面或应用程序资源字典中 
                             // 未找到资源的情况下使用)
    ResourceDictionaryLocation.SourceAssembly //普通资源字典的位置
                             //(在页面、应用程序或任何主题特定资源字典中 
                             // 未找到资源的情况下使用)
)]

// 程序集的版本信息包含以下四个值:
//
//      主要版本
//      次要版本 
//      内部版本号
//      修订
//
// 您可以指定所有值，或者可以默认修订号和内部版本号，
// 方法是按如下方式使用 "*":
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

